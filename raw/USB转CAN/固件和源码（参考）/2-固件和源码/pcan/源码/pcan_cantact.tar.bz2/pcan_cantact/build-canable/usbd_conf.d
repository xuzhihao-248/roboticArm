build-canable/usbd_conf.o: Src/usbd_conf.c \
 Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f0xx.h \
 Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f042x6.h \
 Drivers/CMSIS/Include/core_cm0.h Drivers/CMSIS/Include/cmsis_version.h \
 Drivers/CMSIS/Include/cmsis_compiler.h Drivers/CMSIS/Include/cmsis_gcc.h \
 Drivers/CMSIS/Device/ST/STM32F0xx/Include/system_stm32f0xx.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal.h \
 Src/stm32f0xx_hal_conf.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_rcc.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_def.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_rcc_ex.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_gpio.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_gpio_ex.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_exti.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_dma.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_dma_ex.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_cortex.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_can.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_flash.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_flash_ex.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pcd.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_ll_usb.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pcd_ex.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pwr.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pwr_ex.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_tim.h \
 Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_tim_ex.h \
 Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h \
 Src/usbd_conf.h \
 Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h \
 Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h \
 Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h \
 Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h \
 Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ctlreq.h

Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f0xx.h:

Drivers/CMSIS/Device/ST/STM32F0xx/Include/stm32f042x6.h:

Drivers/CMSIS/Include/core_cm0.h:

Drivers/CMSIS/Include/cmsis_version.h:

Drivers/CMSIS/Include/cmsis_compiler.h:

Drivers/CMSIS/Include/cmsis_gcc.h:

Drivers/CMSIS/Device/ST/STM32F0xx/Include/system_stm32f0xx.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal.h:

Src/stm32f0xx_hal_conf.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_rcc.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_def.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_rcc_ex.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_gpio.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_gpio_ex.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_exti.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_dma.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_dma_ex.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_cortex.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_can.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_flash.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_flash_ex.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pcd.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_ll_usb.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pcd_ex.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pwr.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_pwr_ex.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_tim.h:

Drivers/STM32F0xx_HAL_Driver/Inc/stm32f0xx_hal_tim_ex.h:

Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h:

Src/usbd_conf.h:

Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h:

Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_def.h:

Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ioreq.h:

Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_core.h:

Middlewares/ST/STM32_USB_Device_Library/Core/Inc/usbd_ctlreq.h:
